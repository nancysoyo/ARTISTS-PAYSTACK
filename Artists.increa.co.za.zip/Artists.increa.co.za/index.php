<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Artists</title>

    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="css/business-casual.css" rel="stylesheet">

    <!-- Fonts -->
    <link
        href="http://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800"
        rel="stylesheet" type="text/css">
    <link
        href="http://fonts.googleapis.com/css?family=Josefin+Slab:100,300,400,600,700,100italic,300italic,400italic,600italic,700italic"
        rel="stylesheet" type="text/css">

</head>

<body>

    <div class="brand">Artists</div>


    <!-- Navigation -->
    <?php require_once 'nav.php'; ?>


    <div class="container">
        <div class="row">
            <div class="box">
                <div class="col-lg-12">
                    <hr>
                    <h2 class="intro-text text-center">
                        <strong>Creators</strong>
                    </h2>
                    <hr>
                </div>
                <div class="col-sm-4 text-center">
                    <img class="img-responsive" src="img/Musician.png" width="400" height="500" alt="">
                    <h3>James Moore</h3>
                </div>
                <div class="col-sm-4 text-center">
                    <img class="img-responsive" src="img/painter.png" width="400" height="500" alt="">
                    <h3>Jane Brown</h3>
                </div>
                <div class="col-sm-4 text-center">
                    <img class="img-responsive" src="img/Books.png" width="400" height="500" alt="">
                    <h3>Anne Marie</h3>
                </div>
                <div class="clearfix"></div>
            </div>
        </div>



        <div class="row">
            <div class="box">
                <div class="col-lg-12">
                    <hr>
                    <h2 class="intro-text text-center">Available
                        <strong>Products</strong>
                    </h2>
                    <hr>
                </div>
                <div class="col-md-6">
                    <style>
                        .embed-container {
                            position: relative;
                            padding-bottom: 56.25%;
                            height: 0;
                            overflow: hidden;
                            max-width: 100%;
                        }

                        .embed-container img,
                        .embed-container object,
                        .embed-container embed {
                            position: absolute;
                            top: 0;
                            left: 0;
                            width: 100%;
                            height: 100%;
                        }
                    </style>
                    <div class='embed-container'>

                        <img class="img-responsive" src="img/pexels-cottonbro-7519058.jpg" />
                    </div>

                </div>
                <div class="col-md-6">
                    <h3>James Moore</h3>
                    <p>I saw you dancing in a crowded room
                        You look so happy when I'm not with you
                        But then you saw me, caught you by surprise
                        A single teardrop falling from your eye
                        I don't know why I run away
                        I'll make you cry when I run away
                        You could've asked me why I broke your heart
                        You could've told me that you fell apart
                        But you walked past me like I wasn't there
                        And just pretended like you didn't care.</p>
                    <p>Start your morning off with this great Music.</p>
                    <a href="https://paystack.com/pay/Musics" class="btn btn-info btn-lg" type="button">BUY MUSIC</a>
                    <hr>
                    <!--    </div>-->
                    <!--    <div class="clearfix"></div>-->
                    <!--</div>-->
                </div>
                <div class="col-md-6">
                    <style>
                        .embed-container {
                            position: relative;
                            padding-bottom: 56.25%;
                            height: 0;
                            overflow: hidden;
                            max-width: 100%;
                        }

                        .embed-container img,
                        .embed-container object,
                        .embed-container embed {
                            position: absolute;
                            top: 0;
                            left: 0;
                            width: 100%;
                            height: 100%;
                        }
                    </style>
                    <div class='embed-container'>

                        <img class="img-responsive" src="img/prepaint.png" />
                    </div>

                </div>
                <div class="col-md-6">
                    <h3>Jane Brown</h3>
                    <p>Painting, the expression of ideas and emotions, with the creation of certain aesthetic qualities,
                        in a two-dimensional visual language. The elements of this language—its shapes, lines, colours,
                        tones, and textures—are used in various ways to produce sensations of volume, space, movement,
                        and light on a flat surface.</p>
                    <p>Start your morning off with this great painting.</p>
                    <a href="https://paystack.com/pay/Painting" class="btn btn-info btn-lg" type="button">BUY
                        PAINTING</a>
                    <!--<button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal" action="https://paystack.com/pay/creators">Read More</button>-->
                    <hr>
                </div>
                <!--        <div class="clearfix"></div>-->
                <!--    </div>-->
                <!--</div>-->
                <div class="col-md-6">
                    <style>
                        .embed-container {
                            position: relative;
                            padding-bottom: 56.25%;
                            height: 0;
                            overflow: hidden;
                            max-width: 100%;
                        }

                        .embed-container img,
                        .embed-container object,
                        .embed-container embed {
                            position: absolute;
                            top: 0;
                            left: 0;
                            width: 100%;
                            height: 100%;
                        }
                    </style>
                    <div class='embed-container'>

                        <img class="img-responsive" src="img/bookcover.jpg" />
                    </div>

                </div>
                <div class="col-md-6">
                    <h3>Anne Marie</h3>
                    <p>A CHILD IN SEARCH OF HER STORY Caldecott medalist Mordicai Gerstein looks at books from a whole
                        new angle. Once upon a time there was a family who lived in a book. All but the youngest had
                        stories they belonged to--fighting fires, exploring space, entertaining in the circus--but she
                        didn't have one yet.</p>
                    <p>Start your morning off with this great book.</p>
                    <a href="https://paystack.com/pay/BOOKART" class="btn btn-info btn-lg" type="button">BUY BOOK</a>
                    <hr>
                </div>
                <div class="clearfix"></div>
            </div>
        </div>
    </div>
    <!-- /.container -->

    <footer>
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <p>NancyS</p>
                </div>
            </div>
        </div>
    </footer>

    <!-- jQuery -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

</body>

</html>